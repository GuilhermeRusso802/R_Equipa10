package com.upt.lp.app;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

import com.upt.lp.model.*;
import com.upt.lp.model.Tarefa.Estado;
import com.upt.lp.model.Tarefa.Prioridade;
import com.upt.lp.rest.TarefaRestClient;

/**
 * TaskManager.java
 * Esta classe apresenta o menu principal da aplicação
 * @author Guilherme Russo
 */

public class TaskManager {

    private static ObservableList<Tarefa> tarefasList = FXCollections.observableArrayList();
    private static TarefaRestClient tarefaRestClient = new TarefaRestClient();
    private static Long utilizadorAtualId;
    private static boolean isUpdating = false;
   
    /**
     * Define o Stage da página
     * @param utilizadorId - o id do utilizador atual
     */
    public static void display(Long utilizadorId) {
        utilizadorAtualId = utilizadorId;
        Stage stage = new Stage();
        stage.setTitle("Gestão de Tarefas");
        
        //Cria uma tabela para mostrar as tarefas
        TableView<Tarefa> tableView = new TableView<>();
        TableColumn<Tarefa, String> colunaTitulo = new TableColumn<>("Título");
        colunaTitulo.setCellValueFactory(cellData -> cellData.getValue().tituloProperty());

        TableColumn<Tarefa, String> colunaDescricao = new TableColumn<>("Descrição");
        colunaDescricao.setCellValueFactory(cellData -> cellData.getValue().descricaoProperty());

        TableColumn<Tarefa, Prioridade> colunaPrioridade = new TableColumn<>("Prioridade");
        colunaPrioridade.setCellValueFactory(cellData -> cellData.getValue().prioridadeProperty());

        TableColumn<Tarefa, Estado> colunaStatus = new TableColumn<>("Estado");
        colunaStatus.setCellValueFactory(cellData -> cellData.getValue().estadoProperty());
        
        TableColumn<Tarefa, LocalDate> colunaDataFim = new TableColumn<>("Data Fim");
        colunaDataFim.setCellValueFactory(cellData -> cellData.getValue().dataFimProperty());

        tableView.getColumns().addAll(colunaTitulo, colunaDescricao, colunaPrioridade, colunaStatus, colunaDataFim);
        tableView.setItems(tarefasList);
        
        //Botões
        Button btnAdicionar = new Button("Adicionar");
        Button btnAtualizar = new Button("Atualizar");
        Button btnRemover = new Button("Remover");
        Button btnListarEstado = new Button("Listar por Estado");
        Button btnListarPrioridade = new Button("Listar por Prioridade");
        Button btnListarTodas = new Button("Todas as Tarefas");
        Button btnVoltarLogin = new Button("Encerrar Sessão");
        
        //Define a função do btnAdicionar
        btnAdicionar.setOnAction(e -> adicionarTarefa());
        btnAtualizar.setOnAction(e -> {
            Tarefa tarefaSelecionada = tableView.getSelectionModel().getSelectedItem();
            if (tarefaSelecionada != null) {
                atualizarTarefa(tarefaSelecionada);
            } else {
                exibirAlerta("Seleção Necessária", "Por favor, selecione uma tarefa para atualizar.");
            }
        });

        //Define a função do btnRemover
        btnRemover.setOnAction(e -> {
            Tarefa tarefaSelecionada = tableView.getSelectionModel().getSelectedItem();
            if (tarefaSelecionada != null) {
                removerTarefa(tarefaSelecionada);
            } else {
                exibirAlerta("Seleção Necessária", "Por favor, selecione uma tarefa para remover.");
            }
        });
        
        //Define a função de outros botões
        btnListarEstado.setOnAction(e -> listarPorEstado());
        btnListarPrioridade.setOnAction(e -> listarPorPrioridade());
        btnListarTodas.setOnAction(e -> carregarTarefas());
        
        //Retorna à página de log-in, encerrando a sessão do utilizador
        btnVoltarLogin.setOnAction(e -> {
            stage.close();
            StartingScreen mainApp = new StartingScreen();
            Stage newStage = new Stage();
            try {
                mainApp.start(newStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        
        //Define a posição dos botões
        HBox buttonsTop = new HBox(10, btnAdicionar, btnAtualizar, btnRemover);
        buttonsTop.setAlignment(Pos.CENTER);

        HBox buttonsBottom = new HBox(10, btnListarEstado, btnListarPrioridade, btnListarTodas, btnVoltarLogin);
        buttonsBottom.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, tableView, buttonsTop, buttonsBottom);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        carregarTarefas();
        
        //Insere a informação
        Scene scene = new Scene(layout, 800, 500);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Carrega as tarefas associadas ao utilizador
     */
    private static void carregarTarefas() {
        if (utilizadorAtualId != null) {
            List<Tarefa> tarefas = tarefaRestClient.getTarefasByUtilizadorId(utilizadorAtualId);
            tarefasList.setAll(tarefas);
        }
    }
    
    /**
     * Remove a tarefa selecionada
     * @param tarefa - a tarefa a remover
     */
    private static void removerTarefa(Tarefa tarefa) {
        if (tarefaRestClient.deleteTarefa(tarefa.getId())) {
            carregarTarefas();
            exibirAlerta("Sucesso", "Tarefa removida com sucesso!");
        } else {
            exibirAlerta("Erro", "Não foi possível remover a tarefa.");	
        }
    }

    /**
     * Adiciona uma tarefa
     */
    private static void adicionarTarefa() {
        Stage stage = new Stage();
        stage.setTitle("Adicionar Tarefa");

        TextField txtTitulo = new TextField();
        txtTitulo.setPromptText("Título");
        TextField txtDescricao = new TextField();
        txtDescricao.setPromptText("Descrição");
        DatePicker dataFim = new DatePicker();
        ComboBox<Prioridade> cmbPrioridade = new ComboBox<>(FXCollections.observableArrayList(Prioridade.values()));
        cmbPrioridade.setValue(Prioridade.BAIXA);

        Button btnSalvar = new Button("Salvar");
        btnSalvar.setOnAction(e -> {
            if (!txtTitulo.getText().isEmpty()) {
                Tarefa novaTarefa = new Tarefa();
                novaTarefa.setTitulo(txtTitulo.getText());
                novaTarefa.setDescricao(txtDescricao.getText());
                novaTarefa.setDataFim(dataFim.getValue());
                novaTarefa.setPrioridade(cmbPrioridade.getValue());
                novaTarefa.setEstado(Estado.POR_FAZER);

                // Vai buscar o id do utilizador atual para associar à tarefa
                Long utilizadorId = (novaTarefa.getUtilizador() != null) ? novaTarefa.getUtilizador().getId() : utilizadorAtualId;
                novaTarefa.setUtilizador(new Utilizador());
                novaTarefa.getUtilizador().setId(utilizadorId);
                
                //Define a mensagem enviada
                boolean sucesso = tarefaRestClient.saveTarefa(utilizadorId, novaTarefa);
                if (sucesso) {
                    carregarTarefas();
                    exibirAlerta("Sucesso", "Tarefa adicionada com sucesso!");
                    stage.close();
                } else {
                    exibirAlerta("Erro", "Não foi possível adicionar a tarefa.");
                }
            } else {
                exibirAlerta("Erro", "O título da tarefa não pode estar vazio!");
            }
        });
        
        //Define a scene da página da criação da tarefa
        VBox layout = new VBox(10, txtTitulo, txtDescricao, dataFim, cmbPrioridade, btnSalvar);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 750, 700);
        stage.setScene(scene);
        stage.show();
    }

    
   /**
    * Atualiza a informação da tarefa selecionada
    * @param tarefa - a tarefa a atualizar
    */
    private static void atualizarTarefa(Tarefa tarefa) {
        if (isUpdating) {
            return;
        }
        isUpdating = true;
        
        if (tarefa != null) {
            System.out.println("A atualizar tarefa com ID: " + tarefa.getId());
            
            if (tarefa.getId() > 0) {
                Stage stage = new Stage();
                stage.setTitle("Atualizar Tarefa");

                TextField txtTitulo = new TextField(tarefa.getTitulo());
                TextField txtDescricao = new TextField(tarefa.getDescricao());
                DatePicker dataFim = new DatePicker(tarefa.getDataFim());
                ComboBox<Prioridade> cmbPrioridade = new ComboBox<>(FXCollections.observableArrayList(Prioridade.values()));
                cmbPrioridade.setValue(tarefa.getPrioridade());
                ComboBox<Estado> cmbStatus = new ComboBox<>(FXCollections.observableArrayList(Estado.values()));
                cmbStatus.setValue(tarefa.getEstado());

                Button btnSalvar = new Button("Salvar");
                btnSalvar.setOnAction(e -> {
                    tarefa.setTitulo(txtTitulo.getText());
                    tarefa.setDescricao(txtDescricao.getText());
                    tarefa.setDataFim(dataFim.getValue());
                    tarefa.setPrioridade(cmbPrioridade.getValue());
                    tarefa.setEstado(cmbStatus.getValue());

                    boolean sucesso = tarefaRestClient.updateTarefa(tarefa.getId(), tarefa);
                    if (sucesso) {
                        carregarTarefas();
                        exibirAlerta("Sucesso", "Tarefa atualizada com sucesso.");
                        stage.close();
                    } else {
                        exibirAlerta("Erro", "Falha ao atualizar a tarefa. Verifique os dados e tente novamente.");
                    }
                });

                VBox layout = new VBox(10, txtTitulo, txtDescricao, dataFim, cmbPrioridade, cmbStatus, btnSalvar);
                layout.setPadding(new Insets(20));
                Scene scene = new Scene(layout, 350, 400);
                stage.setScene(scene);
                stage.show();
            } else {
                exibirAlerta("Erro", "ID da tarefa inválido. Verifique se a Tarefa existe.");
            }
        } else {
            exibirAlerta("Erro", "Tarefa inválida.");
        }
        
        isUpdating = false;
    }

    
    /**
     * Lista as tarefas pelo estado selecionado
     */
    private static void listarPorEstado() {
        ChoiceDialog<Estado> dialog = new ChoiceDialog<>(Estado.POR_FAZER, Estado.values());
        dialog.setTitle("Filtrar por Estado");
        dialog.setHeaderText("Escolha o Estado para filtrar");
        dialog.setContentText("Estado:");
        dialog.showAndWait().ifPresent(status -> {
            List<Tarefa> tarefasFiltradas = tarefaRestClient.getTarefasByEstado(utilizadorAtualId, status);
            tarefasList.setAll(tarefasFiltradas);
        });
    }

    /**
     * Lista as tarefas pela prioridade selecionada
     */
    private static void listarPorPrioridade() {
        ChoiceDialog<Prioridade> dialog = new ChoiceDialog<>(Prioridade.BAIXA, Prioridade.values());
        dialog.setTitle("Filtrar por Prioridade");
        dialog.setHeaderText("Escolha a prioridade para filtrar");
        dialog.setContentText("Prioridade:");
        dialog.showAndWait().ifPresent(prioridade -> {
            List<Tarefa> tarefasFiltradas = tarefaRestClient.getTarefasByPrioridade(utilizadorAtualId, prioridade);
            tarefasList.setAll(tarefasFiltradas);
        });
    }
    
   /**
    * Define a base para os alertas enviados
    * @param titulo - titulo do alerta
    * @param mensagem - mensagem mostrada ao utilizador
    */
    private static void exibirAlerta(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
