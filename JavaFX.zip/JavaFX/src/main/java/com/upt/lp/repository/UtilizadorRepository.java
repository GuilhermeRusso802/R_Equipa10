package com.upt.lp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.upt.lp.model.Utilizador;

import java.util.Optional;


/**
 * UtilizadorRepository.java
 * Esta classe possui métodos CRUD associados aos utilizadores que não são suportados nativamente pelo Spring
 * @author Guilherme Russo
 */

@Repository
public interface UtilizadorRepository extends JpaRepository<Utilizador, Long> {
    Optional<Utilizador> findByUsername(String username);
}
