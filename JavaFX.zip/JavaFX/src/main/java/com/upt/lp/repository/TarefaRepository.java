package com.upt.lp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.upt.lp.model.Tarefa;
import com.upt.lp.model.Tarefa.Estado;
import com.upt.lp.model.Tarefa.Prioridade;

import java.util.List;

/**
 * TarefaRepository.java
 * Esta classe possui métodos CRUD associados às tarefas que não são suportados nativamente pelo Spring
 * @author Guilherme Russo
 */


@Repository
public interface TarefaRepository extends JpaRepository<Tarefa, Long> {
    List<Tarefa> findByPrioridade(Prioridade prioridade);
    List<Tarefa> findByEstado(Estado estado);
}
