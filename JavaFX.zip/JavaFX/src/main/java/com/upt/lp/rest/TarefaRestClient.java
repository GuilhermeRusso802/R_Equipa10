package com.upt.lp.rest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import com.upt.lp.model.Tarefa;
import com.upt.lp.model.Tarefa.Estado;
import com.upt.lp.model.Tarefa.Prioridade;

/**
 * TarefaRestClient.java
 * Esta classe possui os métodos CRUD relacionados às tarefas
 * @author Guilherme Russo
 */

public class TarefaRestClient {

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String rootAPIURL = "http://localhost:8080/api/tarefas";
    
    /**
     * Obtém as tarefas associadas ao utilizador ativo
     * @param utilizadorId- o id do utilizador
     */
    public List<Tarefa> getTarefasByUtilizadorId(Long utilizadorId) {
        ResponseEntity<Tarefa[]> response = restTemplate.getForEntity(
            rootAPIURL + "?utilizadorId=" + utilizadorId, Tarefa[].class
        );

        List<Tarefa> tarefas = processList(response);

        //Ordenar por data
        tarefas.sort(Comparator.comparing(Tarefa::getDataFim));

        return tarefas;
    }

    /**
     * Obtém as tarefas pelo seu id
     * @param id - id da tarefa
     */
    public Tarefa getTarefaById(Long id) {
        ResponseEntity<Tarefa> response = restTemplate.getForEntity(
            rootAPIURL + "/" + id, Tarefa.class
        );
        return response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
    }

    /**
     * Obtém as tarefas pela sua prioridade
     * @param utilizadorId - o id do utilizador associado às tarefas.
     * @param prioridade - a prioridade da tarefa.
     */
    public List<Tarefa> getTarefasByPrioridade(Long utilizadorId, Prioridade prioridade) {
        ResponseEntity<Tarefa[]> response = restTemplate.getForEntity(
            rootAPIURL + "/prioridade/" + prioridade + "?utilizadorId=" + utilizadorId, Tarefa[].class
        );
        return processList(response);
    }
    
    /**
     * Obtém as tarefas pelo seu estado
     * @param utilizadorId - o id do utilizador associado às tarefas.
     * @param estado - o estado da tarefa.
     */
    public List<Tarefa> getTarefasByEstado(Long utilizadorId, Estado estado) {
        ResponseEntity<Tarefa[]> response = restTemplate.getForEntity(
            rootAPIURL + "/estado/" + estado + "?utilizadorId=" + utilizadorId, Tarefa[].class
        );
        return processList(response);
    }
    
    /**
     * Guarda a tarefa na base de dados
     * @param utilizadorId - o id do utilizador associado às tarefas.
     * @param tarefa - a tarefa a ser guardada.
     */
    public boolean saveTarefa(Long utilizadorId, Tarefa tarefa) {
        ResponseEntity<Tarefa> response = restTemplate.postForEntity(
            rootAPIURL + "/utilizadores/" + utilizadorId, tarefa, Tarefa.class
        );
        return response.getStatusCode().is2xxSuccessful();
    }

    
    /**
     * Atualiza a informação da tarefa
     * @param id - o id da tarefa a atualizar.
     * @param tarefa - o objeto com os novos dados da tarefa.
     */
    public boolean updateTarefa(Long id, Tarefa tarefa) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Tarefa> requestEntity = new HttpEntity<>(tarefa, headers);

        ResponseEntity<Tarefa> response = restTemplate.exchange(
            rootAPIURL + "/" + id, HttpMethod.PUT, requestEntity, Tarefa.class
        );

        return response.getStatusCode().is2xxSuccessful();
    }
    
    /**
     * Apaga a tarefa da base de dados
     * @param id - o id da tarefa a excluir
     */
    public boolean deleteTarefa(Long id) {
        ResponseEntity<Void> response = restTemplate.exchange(
            rootAPIURL + "/" + id, HttpMethod.DELETE, null, Void.class
        );
        return response.getStatusCode().is2xxSuccessful();
    }
    
    /**
     * Transforma a resposta de um pedido http num arraylist de tarefas
     * @param response - a resposta do pedido http
     * @return arraylist de tarefas
     */
    private List<Tarefa> processList(ResponseEntity<Tarefa[]> response) {
        List<Tarefa> tarefas = new ArrayList<>();
        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
            for (Tarefa t : response.getBody()) {
                tarefas.add(t);
            }
        }
        return tarefas;
    }
}
