package com.upt.lp.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.upt.lp.model.Utilizador;

/**
 * UtilizadorRestClient.java
 * Esta classe possui os métodos CRUD relacionados aos utilizadores.
 * @author Guilherme Russo
 */

public class UtilizadorRestClient {

	private RestTemplate restTemplate = new RestTemplate();
	private static final String userAPIURL = "http://localhost:8080/api/utilizadores";

	/**
	 * Obtém a informação de todos os utilizadores.
	 * @return os utilizadores obtidos.
	 */
	public List<Utilizador> getAllUtilizadores() {
		ResponseEntity<Utilizador[]> response = restTemplate.getForEntity(userAPIURL, Utilizador[].class);
		List<Utilizador> utilizadores = new ArrayList<>();
		if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
			for (Utilizador u : response.getBody()) {
				utilizadores.add(u);
			}
		}
		return utilizadores;
	}
	
	/**
	 * Obtém a informação de um utilizador pelo seu id.
	 * @param id - o id do utilizador a procurar.
	 */
	public Utilizador getUtilizadorById(Long id) {
		ResponseEntity<Utilizador> response = restTemplate.getForEntity(userAPIURL + "/" + id, Utilizador.class);
		return response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
	}
	
	/**
	 * Obtém a informação de um utilizador pelo seu username.
	 * @param username - o username do utilizador.
	 */
    public Utilizador getUtilizadorByUsername(String username) {
        try {
            ResponseEntity<Utilizador> response = restTemplate.getForEntity(userAPIURL + "/username/" + username, Utilizador.class);
            return response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
        } catch (HttpClientErrorException.NotFound e) {
            System.out.println("Utilizador não encontrado: " + username);
            return null;
        } catch (Exception e) {
            System.out.println("Erro ao buscar utilizador: " + e.getMessage());
            return null;
        }
    }
    
    /**
	 * Guarda um utilizador na base de dados.
	 * @param utilizador - o utilizador a ser guardado.
	 */
	public boolean saveUtilizador(Utilizador utilizador) {
		ResponseEntity<Utilizador> response = restTemplate.postForEntity(userAPIURL, utilizador, Utilizador.class);
		return response.getStatusCode().is2xxSuccessful();
	}
	
	/**
	 * Apaga um utilizador da base de dados.
	 * @param id - o id do utilizador a ser apagado.
	 */
	public boolean deleteUtilizador(Long id) {
		ResponseEntity<Void> response = restTemplate.exchange(userAPIURL + "/" + id, HttpMethod.DELETE, null, Void.class);
		return response.getStatusCode().is2xxSuccessful();
	}
}