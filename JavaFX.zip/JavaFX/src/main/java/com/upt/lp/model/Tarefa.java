package com.upt.lp.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javafx.beans.property.*;

/**
 * Tarefa.java
 * Esta classe está associada a uma tabela na base de dados
 * @author Guilherme Russo
 */

@Entity
@Table(name = "tarefas")
public class Tarefa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String titulo;

    private String descricao;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @Enumerated(EnumType.STRING)
    private Prioridade prioridade;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    @ManyToOne
    @JoinColumn(name = "utilizador_id", referencedColumnName = "id")
    @JsonBackReference
    private Utilizador utilizador;
    
    //Tipos possíveis de prioridade
    public enum Prioridade {
        BAIXA, MEDIA, ALTA;
    }
    
    //Tipos possíveis de estado
    public enum Estado {
        POR_FAZER, EM_PROGRESSO, CONCLUIDA;
    }
    
    /**
     * No-arg constructor
     */
    public Tarefa() {
    }

    /**
     * @return o id da tarefa
     */
    public long getId() {
        return id;
    }

   /**
    * @param id - o id da tarefa
    */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return o titulo da tarefa
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo - o titulo da tarefa
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    /**
     * @return o titulo da tarefa
     */
    public StringProperty tituloProperty() {
        return new SimpleStringProperty(titulo);
    }

   /**
    * @return a descrição da tarefa
    */
    public String getDescricao() {
        return descricao;
    }
    
    /**
     * @param descricao - a descrição da tarefa
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    /**
     * @return a descrição da tarefa 
     */
    public StringProperty descricaoProperty() {
        return new SimpleStringProperty(descricao);
    }

    /**
     * @return a data de fim da tarefa
     */
    public LocalDate getDataFim() {
        return dataFim;
    }
    
    /**
     * @param dataFim - a data de fim da tarefa
     */
    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }
    
    /**
     * @return a data de fim da tarefa
     */
    public ObjectProperty<LocalDate> dataFimProperty() {
        return new SimpleObjectProperty<>(dataFim);
    }
    
    /**
     * @return a prioridade da tarefa
     */
    public Prioridade getPrioridade() {
        return prioridade;
    }

    /**
     * @param prioridade - a prioridade da tarefa
     */
    public void setPrioridade(Prioridade prioridade) {
        this.prioridade = prioridade;
    }

    /**
     * @return a prioridade da tarefa
     */
    public ObjectProperty<Prioridade> prioridadeProperty() {
        return new SimpleObjectProperty<>(prioridade);
    }
    
    
    /**
     * @return o estado da tarefa
     */
    public Estado getEstado() {
        return estado;
    }

    /**
     * @param estado - o estado da tarefa
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    /**
     * @return o estado da tarefa
     */
    public ObjectProperty<Estado> estadoProperty() {
        return new SimpleObjectProperty<>(estado);
    }

    /**
     * @return o utilizador associado
     */
    public Utilizador getUtilizador() {
        return utilizador;
    }

    /**
     * @param utilizador - o utilizador associado
     */
    public void setUtilizador(Utilizador utilizador) {
        this.utilizador = utilizador;
    }
    
    @Override
    public String toString() {
        return "Tarefa [id=" + id + ", titulo=" + titulo + ", descricao=" + descricao + ", dataFim=" + dataFim + ", prioridade=" + prioridade + ", estado=" + estado + ", utilizador=" + utilizador + "]";
    }
}