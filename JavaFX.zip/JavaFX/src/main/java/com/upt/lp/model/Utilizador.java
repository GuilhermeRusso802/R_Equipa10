package com.upt.lp.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/**
 * Utilizador.java
 * Esta classe está associada a uma tabela na base de dados
 * @author Guilherme Russo
 */

@Entity
@Table(name = "utilizadores")
public class Utilizador {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    @OneToMany(mappedBy = "utilizadores")
    @JsonManagedReference
    private List<Tarefa> tarefas;

    
    /**
     * @return o id do utilizador
     */
    public long getId() {
        return id;
    }
    
    /**
     * @param id - o id do utilizador
     */
    public void setId(long id) {
        this.id = id;
    }
    
    /**
     * @return o username do utilizador
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username - o username do utilizador
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return a password do utilizador
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password - a password do utilizador
     */
    public void setPassword(String password) {
        this.password = password;
    }
    
    /**
     * @return as tarefas associadas ao utilizador
     */
    public List<Tarefa> getTarefas() {
        return tarefas;
    }

    /**
     * @param tarefas - as tarefas associadas ao utilizador
     */
    public void setTarefas(List<Tarefa> tarefas) {
        this.tarefas = tarefas;
    }

    /**
     * Associa uma tarefa ao utilizador
     * @param tarefa - a tarefa a adicionar
     */
    public void addTarefa(Tarefa tarefa) {
        this.tarefas.add(tarefa);
        tarefa.setUtilizador(this);
    }
    
    /**
     * Exclui uma tarefa
     * @param tarefa - a tarefa a remover
     */
    public void removeTarefa(Tarefa tarefa) {
        this.tarefas.remove(tarefa);
        tarefa.setUtilizador(null);
    }

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password=" + password + ", tarefas=" + tarefas + "]";
	}
}
