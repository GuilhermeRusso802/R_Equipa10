package com.upt.lp.app;

import com.upt.lp.model.*;
import com.upt.lp.rest.*;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/** 
* SignUpScreen.java 
* Esta classe representa o ecrã onde se criam novos utilizadores. 
* @author Guilherme Russo 
* 
*/ 

public class SignUpScreen {

    public static void display() {
        Stage stage = new Stage();
        stage.setTitle("Registo");

        Label lblUsername = new Label("Username:");
        TextField txtUsername = new TextField();
        
        Label lblPassword = new Label("Senha:");
        PasswordField txtPassword = new PasswordField();
        
        Button btnRegistrar = new Button("Registar");
        btnRegistrar.setOnAction(e -> realizarRegisto(txtUsername.getText(), txtPassword.getText()));
        
        Button btnVoltar = new Button("Voltar");
        btnVoltar.setOnAction(e -> stage.close());

        // Hbox criada para centralizar os botões
        HBox buttonBox = new HBox(10, btnRegistrar, btnVoltar);
        buttonBox.setAlignment(Pos.CENTER); // Botões centralizados

        // Criar VBox principal
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER); // Botões centralizados
        layout.getChildren().addAll(lblUsername, txtUsername, lblPassword, txtPassword, buttonBox);

        Scene scene = new Scene(layout, 500, 350);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * Regista o utilizador na base de dados
     * @param username - o username do utilizador.
     * @param senha - a senha do utilizador.
     */
    private static void realizarRegisto(String username, String senha) {
        UtilizadorRestClient userRestClient = new UtilizadorRestClient();
        Utilizador newUtilizador = new Utilizador();
        newUtilizador.setUsername(username);
        newUtilizador.setPassword(senha);
        
        boolean success = userRestClient.saveUtilizador(newUtilizador);
        if (success) {
            System.out.println("Registo bem-sucedido para: " + username);
        } else {
            System.out.println("Erro no registo");
        }
    }
}
