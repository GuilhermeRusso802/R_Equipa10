package com.upt.lp.launcher;

import java.io.Serializable;

import com.upt.lp.app.StartingScreen;

import javafx.application.Application;

/**
 * JavaFxLauncher.java
 * Esta classe inicia a interface em JavaFX
 * @author Guilherme Russo
 */

public class JavaFxLauncher {
	public static void main(String[]args) {
		Application.launch(StartingScreen.class,args);
	}

}
	