package com.upt.lp.app;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/** 
* StartingScreen.java 
* Esta classe representa o ecrã inicial da aplicação. 
* @author Guilherme Russo 
* 
*/ 


public class StartingScreen extends Application {

    @Override
    public void start(Stage primaryStage) {
    	//Cria a janela
        primaryStage.setTitle("Gestão de Tarefas");
        
        Button btnLogin = new Button("Login");
        btnLogin.setOnAction(e -> abrirTelaLogin());
        
        Button btnRegistro = new Button("Registar");
        btnRegistro.setOnAction(e -> abrirTelaRegistar());

        //Cria uma vbox
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER); // Centraliza os botões
        layout.getChildren().addAll(btnLogin, btnRegistro);
        
        //Adiciona o conteúdo
        Scene scene = new Scene(layout, 800, 450);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    /**
     * Abre a página de login
     */
    private void abrirTelaLogin() {
        LoginScreen.display();
    }
    
    /**
     * abre a página de registo
     */
    private void abrirTelaRegistar() {
        SignUpScreen.display();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
