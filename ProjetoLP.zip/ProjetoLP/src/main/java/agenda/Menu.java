package agenda;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import agenda.Tarefa.Estado;
import agenda.Tarefa.Prioridade;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
        SessionFactory sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();

        UtilizadorManager utilizadorManager = new UtilizadorManager(sessionFactory);
        TarefaManager tarefaManager = new TarefaManager(sessionFactory);
        Scanner scanner = new Scanner(System.in);
        
        /**
         * Verificação de Credenciais
         */
        while (true) {
            System.out.print("1. Login \n");
            System.out.print("2. Registar ");
            int escolha = scanner.nextInt();
            scanner.nextLine();
            //Criação de um novo utilizador
            if (escolha == 1) {
                System.out.print("Username: ");
                String username = scanner.nextLine();
                System.out.print("Password: ");
                String password = scanner.nextLine();
                if (utilizadorManager.autenticarUtilizador(username, password)) {
                    Utilizador userAtual = utilizadorManager.utilizadorPorUsername(username);
                    System.out.println("Verifição bem sucedida.");
                    mostrarMenu(scanner, tarefaManager, userAtual);
                } else {
                    System.out.println("Utilizador não encontrado. Verifique as credenciais inseridas");
                }
                //Log-In
            } else if (escolha == 2) {
                System.out.print("Insira o seu nome de utilizador: ");
                String username = scanner.nextLine();
                System.out.print("Insira a password: ");
                String password = scanner.nextLine();
                utilizadorManager.criarUtilizador(username, password);
                System.out.println("Utilizador criado com sucesso.");
            } else {
                System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
    
    /**
     * Opções do Menu.
     */
    private static void mostrarMenu(Scanner scanner, TarefaManager tarefaManager, Utilizador userAtual) {
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        int op;
        do {
            System.out.println("\nMenu Principal:");
            System.out.println("1. Adicionar Tarefa");
            System.out.println("2. Mostrar Tarefas");
            System.out.println("3. Mostrar Tarefas por Prioridade");
            System.out.println("4. Ordenar Tarefas por ordem de Data");
            System.out.println("5. Atualizar Tarefa");
            System.out.println("6. Excluir Tarefa");
            System.out.println("7. Marcar Tarefa como Concluída");
            System.out.println("8. Sair");
            System.out.print("Escolha uma opção: ");
            op = scanner.nextInt();
            scanner.nextLine();

            switch (op) {
            	//Adicionar Tarefa
                case 1:
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Descrição: ");
                    String descricao = scanner.nextLine();
                    System.out.print("Data de Fim (YYYY-MM-DD): ");
                    String dataFInput = scanner.nextLine();
                    LocalDate dataF = LocalDate.parse(dataFInput, formatter);
                    System.out.print("Prioridade (BAIXA, MEDIA, ALTA): ");
                    Prioridade prioridade = Prioridade.valueOf(scanner.nextLine().toUpperCase());
                    Estado estado = Estado.POR_FAZER;
                    tarefaManager.criarTarefa(titulo, descricao, dataF, prioridade, estado, userAtual);
                    System.out.println("Tarefa adicionada com sucesso.");
                    break;
                    //Mostrar tarefas
                case 2:
                    List<Tarefa> tarefas = tarefaManager.listarTarefas(userAtual);
                    for (Tarefa t : tarefas) {
                        System.out.println("ID: " + t.getId() + ", Título: " + t.getTitulo() + ", Estado: " + t.getEstado());
                    }
                    break;
                    //Mostrar por prioridade
                case 3:
                    System.out.print("Prioridade (BAIXA, MEDIA, ALTA): ");
                    prioridade = Prioridade.valueOf(scanner.nextLine().toUpperCase());
                    List<Tarefa> tarefasFiltradas = tarefaManager.listarTarefasPorPrioridade(userAtual, prioridade);
                    for (Tarefa t : tarefasFiltradas) {
                        System.out.println("ID: " + t.getId() + ", Título: " + t.getTitulo() + ", Estado: " + t.getEstado());
                    }
                    break;
                    //Mostrar por data de fim
                case 4:
                	List<Tarefa> tarefasOrdenadas = tarefaManager.listarTarefasPorDataFim(userAtual);
                	for (Tarefa t : tarefasOrdenadas) {
                        System.out.println("ID: " + t.getId() + ", Título: " + t.getTitulo() + ", Estado: " + t.getEstado());
                	}
                	//Atualizar Tarefa
                case 5:
                    System.out.print("ID da Tarefa para atualizar: ");
                    Long id = scanner.nextLong();
                    scanner.nextLine();

                    System.out.println("Selecione o que deseja atualizar:");
                    System.out.println("1. Título");
                    System.out.println("2. Descrição");
                    System.out.println("3. Data de Fim");
                    System.out.println("4. Prioridade");
                    System.out.println("5. Estado");
                    System.out.print("Escolha uma opção: ");
                    int opc = scanner.nextInt();
                    scanner.nextLine();

                    Tarefa tarefa = null;
                    switch (opc) {
                        case 1:
                            System.out.print("Novo Título: ");
                            String novoTitulo = scanner.nextLine();
                            tarefaManager.atualizarTarefa(id, novoTitulo, null, null, null, null);
                            break;
                        case 2:
                            System.out.print("Nova Descrição: ");
                            String novaDescricao = scanner.nextLine();
                            tarefaManager.atualizarTarefa(id, null, novaDescricao, null, null, null);
                            break;
                        case 3:
                            System.out.print("Nova Data de Fim (YYYY-MM-DD): ");
                            String novaDataInput = scanner.nextLine();
                            LocalDate novaData = LocalDate.parse(novaDataInput, formatter);
                            tarefaManager.atualizarTarefa(id, null, null, novaData, null, null);
                            break;
                        case 4:
                            System.out.print("Nova Prioridade (BAIXA, MEDIA, ALTA): ");
                            Prioridade novaPrioridade = Prioridade.valueOf(scanner.nextLine().toUpperCase());
                            tarefaManager.atualizarTarefa(id, null, null, null, novaPrioridade, null);
                            break;
                        case 5:
                            System.out.print("Novo Estado (POR_FAZER, EM_PROGRESSO, CONCLUIDA): ");
                            Estado novoEstado = Estado.valueOf(scanner.nextLine().toUpperCase());
                            tarefaManager.atualizarTarefa(id, null, null, null, null, novoEstado);
                            break;
                        default:
                            System.out.println("Opção inválida para atualização de tarefa.");
                    }
                    System.out.println("Tarefa atualizada.");
                    break;
                    //Remover tarefa
                case 6:
                    System.out.print("ID da Tarefa para remover: ");
                    id = scanner.nextLong();
                    tarefaManager.excluirTarefa(id);
                    System.out.println("Tarefa removida.");
                    break;
                    //Marcar como concluida
                case 7:
                    System.out.print("ID da Tarefa para marcar como concluída: ");
                    id = scanner.nextLong();
                    tarefaManager.marcarConcluida(id);
                    System.out.println("Tarefa marcada como concluída.");
                    break;
                    //Sair do Menu
                case 8:
                    System.out.println("A sair.");
                    break;
                default:
                    System.out.println("Opção inválida, tente novamente.");
            }
        } while (op != 7);
    }
}