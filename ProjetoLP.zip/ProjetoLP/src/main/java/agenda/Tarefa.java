package agenda;

import jakarta.persistence.*;
import java.time.LocalDate;


/** 
* Tarefa.java 
* Esta classe conecta a uma tabela na base de dados. 
* @author Guilherme Russo 
* 
*/ 


@Entity
@Table(name ="tarefa")
public class Tarefa {
	@Id 
	@Column(name = "tarefa_id") 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private long id;
	@Column(name = "titulo", nullable = false, length = 100)
    private String titulo;

    @Column(name = "descricao", length = 500)
    private String descricao;

    @Column(name = "data_vencimento")
    private LocalDate dataF;

    @Enumerated(EnumType.STRING)
    @Column(name = "prioridade", nullable = false)
    private Prioridade prioridade;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false)
    private Estado estado;
    
    @ManyToOne
    @JoinColumn(name ="utilizador_id")
    private Utilizador utilizador;
    
    /** 
    * Tipos possíveis de prioridade 
    */ 
	public enum Prioridade {
		BAIXA, MEDIA, ALTA
	}
	
	/** 
	* Tipos possíveis de estado 
	*/ 
	public enum Estado {
		POR_FAZER, EM_PROGRESSO, CONCLUIDA
	}
	
	/** 
	* no-arg constructor 
	*/ 
	public Tarefa() {
	}
	
	/** 
	* @return o titulo 
	*/ 
	public String getTitulo() {
		return titulo;
	}
	
	/** 
	* @param titulo o titulo da tarefa
	*/ 
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	/** 
	* @return a descrição
	*/ 
	public String getDescricao() {
		return descricao;
	}

	/** 
	* @param descricao a descrição da tarefa
	*/ 
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	/** 
	* @return a data limite
	*/ 
	public LocalDate getDataF() {
		return dataF;
	}
	
	/** 
	* @param dataF a data limite da tarefa
	*/ 
	public void setDataF(LocalDate dataF) {
		this.dataF = dataF;
	}

	/** 
	* @return a prioridade
	*/ 
	public Prioridade getPrioridade() {
		return prioridade;
	}
	
	/** 
	* @param prioridade a prioridade da tarefa
	*/ 
	public void setPrioridade(Prioridade prioridade) {
		this.prioridade = prioridade;
	}
	
	/** 
	* @return o estado
	*/ 
	public Estado getEstado() {
		return estado;
	}
	
	/** 
	* @param estado o estado da tarefa
	*/ 
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
	/** 
	* @return o identificador
	*/ 
	public void setId(long id) {
		this.id = id;
	}
	
	/** 
	* @param id o identificador da tarefa
	*/ 
	public long getId() {
		return id;
	}
	
	/** 
	* @param utilizador o utilizador associado à tarefa
	*/ 
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
	/** 
	* @return o utilizador
	*/ 
	public Utilizador getUtilizador (Utilizador utilizador) {
		return utilizador;
	}

	@Override
	public String toString() {
		return "Tarefa [id=" + id + ", titulo=" + titulo + ", descricao=" + descricao + ", dataF=" + dataF
				+ ", prioridade=" + prioridade + ", estado=" + estado + "]";
	}
	
}
