package agenda;

import java.time.LocalDate;
import java.util.List;


import agenda.*;
import agenda.Tarefa.Estado;
import agenda.Tarefa.Prioridade;

import org.hibernate.Session; 
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources; 
import org.hibernate.boot.registry.StandardServiceRegistry; 
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class TarefaManager { 
    protected SessionFactory sessionFactory; 
  
    public TarefaManager(SessionFactory sessionFactory) {
    	this.sessionFactory = sessionFactory;
    }
    
    
    /** 
      * Insere uma tarefa se não existir na base de dados 
      * @param titulo o titulo da tarefa
      * @param descricao a descrição da tarefa
      * @param dataF a data limite da tarefa
      * @param prioridade a prioridade da tarefa
      * @param estado o estado atual da tarefa
      * @param utilizador o utilizador associado
      */
    protected void criarTarefa(String titulo, String descricao, LocalDate dataF, Prioridade prioridade, Estado estado, Utilizador utilizador) { 
        Session session = sessionFactory.openSession();  
        session.beginTransaction(); 
        
        Tarefa existingTarefa = verificarTarefaExiste(session, titulo); 
        if (existingTarefa == null) { 
            Tarefa tarefa = new Tarefa();  
            tarefa.setTitulo(titulo); 
            tarefa.setDescricao(descricao);  
            tarefa.setDataF(dataF); 
            tarefa.setPrioridade(prioridade); 
            tarefa.setEstado(estado); 
            tarefa.setUtilizador(utilizador);
            session.persist(tarefa); 
            System.out.println("Nova tarefa criada: " + tarefa.getTitulo()); 
        } else { 
            System.out.println("A tarefa já existe: " + existingTarefa.getTitulo()); 
        } 
     
        session.getTransaction().commit(); 
        session.close(); 
    } 
    
    /** 
     * Verifica se a tarefa existe, verificando o titulo
     * @param session 
     * @param titulo o titulo da tarefa
     * @return null se a tarefa não existir
     */ 
    private Tarefa verificarTarefaExiste(Session session, String titulo) { 
        List<Tarefa> tarefas = session.createQuery(
        		"FROM Tarefa WHERE titulo = :titulo", Tarefa.class)
                .setParameter("titulo", titulo)
                .getResultList(); 
        if (!tarefas.isEmpty()) {
        	return tarefas.get(0);
        } else {
        	return null;
        }
    }
 
  
    /**
     * Imprime as informações de uma tarefa com um ID fornecido.
     * @param tarefaId o ID da tarefa a ser impressa.
     */
    protected void lerTarefa(long tarefaId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Tarefa tarefa = session.get(Tarefa.class, tarefaId);

        if (tarefa != null) {
            System.out.println("Tarefa encontrada:");
            System.out.println("ID da Tarefa: " + tarefa.getId());
            System.out.println("Título: " + tarefa.getTitulo());
            System.out.println("Descrição: " + tarefa.getDescricao());
            System.out.println("Data Final: " + tarefa.getDataF());
            System.out.println("Prioridade: " + tarefa.getPrioridade());
            System.out.println("Estado: " + tarefa.getEstado());
        } else {
            System.out.println("Nenhuma tarefa encontrada com ID: " + tarefaId);
        }

        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * Imprime todas as tarefas.
     * @param utilizador o utilizador associado às tarefas.
     * @return as tarefas do utilizador
     */
    protected List<Tarefa> listarTarefas(Utilizador utilizador) { 
    	Session session = sessionFactory.openSession();
        String hql = "FROM Tarefa WHERE utilizador.id = :utilizadorId";
        List<Tarefa> tarefas = session.createQuery(hql, Tarefa.class)
                                      .setParameter("utilizadorId", utilizador.getId())
                                      .getResultList();
        session.close();
        return tarefas;
    }
    
    /**
     * Imprime todas as tarefas de uma certa prioridade.
     * @param utilizador o utilizador associado às tarefas.
     * @param prioridade a prioridade da tarefa.
     * @return as tarefas com a prioridade fornecida
     */
    public List<Tarefa> listarTarefasPorPrioridade(Utilizador utilizador, Prioridade prioridade) {
        Session session = sessionFactory.openSession();
        String hql = "FROM Tarefa WHERE utilizador.id = :utilizadorId AND prioridade = :prioridade";
        List<Tarefa> tarefas = session.createQuery(hql, Tarefa.class)
                                      .setParameter("utilizadorId", utilizador.getId())
                                      .setParameter("prioridade", prioridade)
                                      .getResultList();
        session.close();
        return tarefas;
    }
    
    /**
     * Lista todas as tarefas de um utilizador, ordenadas por data de fim.
     * @param utilizador o utilizador associado às tarefas.
     * @return Lista de tarefas ordenadas por data de fim.
     */
    public List<Tarefa> listarTarefasPorDataFim(Utilizador utilizador) {
        Session session = sessionFactory.openSession();
        String hql = "FROM Tarefa WHERE utilizador.id = :utilizadorId ORDER BY dataF";
        List<Tarefa> tarefas = session.createQuery(hql, Tarefa.class)
                                      .setParameter("utilizadorId", utilizador.getId())
                                      .getResultList();
        session.close();
        return tarefas;
    }


    
    /** 
     * Atualiza a informação de uma tarefa
     * @param id o identificador da tarefa a atualizar
     * @param titulo o titulo da tarefa
     * @param descricao a descrição da tarefa
     * @param dataF a data limite da tarefa
     * @param prioridade a prioridade da tarefa
     * @param estado o estado atual da tarefa
     * @param utilizador o utilizador associado
     */
    protected void atualizarTarefa(Long id, String titulo, String descricao, LocalDate dataF, Prioridade prioridade, Estado estado) {
    	Session session = sessionFactory.openSession();
        session.beginTransaction();
        Tarefa tarefa = session.get(Tarefa.class, id);
        if (tarefa != null) {
            tarefa.setTitulo(titulo);
            tarefa.setDescricao(descricao);
            tarefa.setDataF(dataF);
            tarefa.setPrioridade(prioridade);
            tarefa.setEstado(estado);

        session.merge(tarefa);
        }
        session.getTransaction().commit();
        session.close();
       
    }

  
    /**
     * Exclui uma tarefa.
     * @param id - o ID da tarefa a ser excluída.
     */
    protected void excluirTarefa(Long id) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        // Recupera a tarefa pelo ID
        Tarefa tarefa = session.get(Tarefa.class, id);

        if (tarefa != null) {
            // Remove a tarefa
            session.remove(tarefa);
            System.out.println("Tarefa excluída: " + tarefa);
        } else {
            System.out.println("Tarefa com ID: " + id + " não encontrada.");
        }

        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * Altera o estado da tarefa para concluída.
     * @param id - o ID da tarefa a ser alterada.
     */
    public void marcarConcluida(Long id) {
       Session session = sessionFactory.openSession();
       session.beginTransaction();
        Tarefa tarefa = session.get(Tarefa.class, id);
        if (tarefa != null) {
            tarefa.setEstado(Estado.CONCLUIDA);
            session.merge(tarefa);
        }
        session.getTransaction().commit();
        session.close();
    }

    
}