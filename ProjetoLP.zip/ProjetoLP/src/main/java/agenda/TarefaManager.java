package agenda;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session; 
import org.hibernate.SessionFactory; 
import org.hibernate.boot.MetadataSources; 
import org.hibernate.boot.registry.StandardServiceRegistry; 
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class TarefaManager { 
    protected SessionFactory sessionFactory; 
  
    
    protected void setup() { 
    	 final StandardServiceRegistry registry = new StandardServiceRegistryBuilder() 
    	        .configure("hibernate.cfg.xml") 
    	        .build(); 
    	   try { 
    	    sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory(); 
    	   } catch (Exception ex) { 
    	    StandardServiceRegistryBuilder.destroy(registry); 
    	    ex.printStackTrace();
            throw new RuntimeException("Erro ao configurar o SessionFactory.");
    	 }
    } 
  
    protected void exit() { 
    	 sessionFactory.close(); 
    } 
    
    
    /** 
      * Insere uma tarefa se não existir na base de dados 
      */
    protected void createTarefa(String titulo, String descricao, LocalDate dataF, Tarefa.Prioridade prioridade, Tarefa.Estado estado) { 
        Session session = sessionFactory.openSession();  
        session.beginTransaction(); 
        
        Tarefa existingTarefa = checkIfTarefaExists(session, titulo); 
        if (existingTarefa == null) { 
            Tarefa tarefa = new Tarefa();  
            tarefa.setTitulo(titulo); 
            tarefa.setDescricao(descricao);  
            tarefa.setDataF(dataF); 
            tarefa.setPrioridade(prioridade); 
            tarefa.setEstado(estado); 
            session.persist(tarefa); 
            System.out.println("Nova tarefa criada: " + tarefa.getTitulo()); 
        } else { 
            System.out.println("A tarefa já existe: " + existingTarefa.getTitulo()); 
        } 
     
        session.getTransaction().commit(); 
        session.close(); 
    } 
    
    /** 
     * Method to check if the book exists based on unique fields (title in this case) 
     * @param session 
     * @param titulo
     * @return null se o livro não existir
     */ 
    private Tarefa checkIfTarefaExists(Session session, String titulo) { 
        List<Tarefa> tarefas = session.createQuery(
        		"FROM Tarefa WHERE titulo = :titulo", Tarefa.class)
                .setParameter("titulo", titulo)
                .getResultList(); 
        if (!tarefas.isEmpty()) {
        	return tarefas.get(0);
        } else {
        	return null;
        }
    }
 
  
    /**
     * Imprime as informações de uma tarefa com um ID fornecido.
     * @param tarefaId o ID da tarefa a ser impressa.
     */
    protected void read(long tarefaId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Tarefa tarefa = session.get(Tarefa.class, tarefaId);

        if (tarefa != null) {
            System.out.println("Tarefa encontrada:");
            System.out.println("ID da Tarefa: " + tarefa.getId());
            System.out.println("Título: " + tarefa.getTitulo());
            System.out.println("Descrição: " + tarefa.getDescricao());
            System.out.println("Data Final: " + tarefa.getDataF());
            System.out.println("Prioridade: " + tarefa.getPrioridade());
            System.out.println("Estado: " + tarefa.getEstado());
        } else {
            System.out.println("Nenhuma tarefa encontrada com ID: " + tarefaId);
        }

        session.getTransaction().commit();
        session.close();
    }

    /**
     * Imprime todas as informações das tarefas.
     */
    protected void readAllTarefas() {
        Session session = sessionFactory.openSession();

        session.beginTransaction();

        List<Tarefa> tarefas = session.createQuery("from Tarefa", Tarefa.class).getResultList();

        for (Tarefa tarefa : tarefas) {
            System.out.println(tarefa);
        }

        session.getTransaction().commit();
        session.close();
    }

  
    protected void update() {
        Tarefa tarefa = new Tarefa();
        tarefa.setId(1); 
        tarefa.setTitulo("Estudar Hibernate");
        tarefa.setDescricao("Revisar os conceitos principais de Hibernate e mapeamento.");
        tarefa.setDataF(LocalDate.of(2025, 1, 25));
        tarefa.setPrioridade(Tarefa.Prioridade.MEDIA);
        tarefa.setEstado(Tarefa.Estado.EM_PROGRESSO);

        Session session = sessionFactory.openSession();
        session.beginTransaction();

        session.merge(tarefa);

        session.getTransaction().commit();
        session.close();
    }

  
    /**
     * Exclui uma tarefa.
     * @param tarefaId - o ID da tarefa a ser excluída.
     */
    protected void delete(Long tarefaId) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        // Recupera a tarefa pelo ID
        Tarefa tarefa = session.get(Tarefa.class, tarefaId);

        if (tarefa != null) {
            // Remove a tarefa
            session.remove(tarefa);
            System.out.println("Tarefa excluída: " + tarefa);
        } else {
            System.out.println("Tarefa com ID: " + tarefaId + " não encontrada.");
        }

        session.getTransaction().commit();
        session.close();
    }

    
    public void utilizadorTarefas() {

        Session session = sessionFactory.openSession();
        session.beginTransaction();


        Utilizador utilizador = new Utilizador();
        utilizador.setUsername("joao123");
        utilizador.setPassword("senhaSegura");

        Tarefa tarefa1 = new Tarefa();
        Tarefa tarefa2 = new Tarefa();

        tarefa1.setTitulo("Estudar Hibernate");
        tarefa1.setDescricao("Revisar o mapeamento de entidades");
        tarefa1.setDataF(LocalDate.of(2025, 2, 10));
        tarefa1.setPrioridade(Tarefa.Prioridade.ALTA);
        tarefa1.setEstado(Tarefa.Estado.POR_FAZER);

        tarefa2.setTitulo("Planejar projeto");
        tarefa2.setDescricao("Definir os requisitos do novo sistema");
        tarefa2.setDataF(LocalDate.of(2025, 2, 15));
        tarefa2.setPrioridade(Tarefa.Prioridade.MEDIA);
        tarefa2.setEstado(Tarefa.Estado.POR_FAZER);


        utilizador.getTarefas().add(tarefa1);
        utilizador.getTarefas().add(tarefa2);


        tarefa1.setUtilizador(utilizador);
        tarefa2.setUtilizador(utilizador);


        session.persist(utilizador);

 
        session.getTransaction().commit();

        System.out.println("Utilizador e tarefas salvos com sucesso!");
        session.close();
    }
    
    protected void printUtilizadorTarefas() {
        Session session = sessionFactory.openSession();


        session.beginTransaction();

        
        List<Utilizador> utilizadores = session.createQuery("from Utilizador", Utilizador.class).getResultList();

      
        for (Utilizador utilizador : utilizadores) {
            System.out.println("Utilizador: " + utilizador.getUsername());

           
            List<Tarefa> tarefas = utilizador.getTarefas();

            if (tarefas.isEmpty()) {
                System.out.println("Este utilizador não tem tarefas associadas.");
            } else {
                System.out.println("Tarefas do utilizador " + utilizador.getUsername() + ":");
                for (Tarefa tarefa : tarefas) {
                    System.out.println(tarefa);
                }
            }
            System.out.println("---------------------------------------");
        }

        // Finaliza a transação
        session.getTransaction().commit();
        session.close();
    }


   
    public static void main(String[] args) { 
    	TarefaManager manager = new TarefaManager(); 
    manager.setup(); 
  
    manager.exit(); 
    } 
}