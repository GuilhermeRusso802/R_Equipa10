package agenda;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


public class UtilizadorManager {
    private SessionFactory sessionFactory;

    public UtilizadorManager(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    /**
     * Cria um novo utilizador.
     * @param username - o username do utilizador.
     * @param password - a password do utilizador.
     */
    public void criarUtilizador(String username, String password) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Utilizador user = new Utilizador();
        user.setUsername(username);
        user.setPassword(password);
        session.persist(user);
        session.getTransaction().commit();
        session.close();
    }
    
    /**
     * Verifica se o utilizador está registado na base de dados.
     * @param username - o username do utilizador.
     * @param password - a password do utilizador.
     */
    public boolean autenticarUtilizador(String username, String password) {
        Session session = sessionFactory.openSession();
        String hql = "FROM User WHERE username = :username AND password = :password";
        Utilizador user = session.createQuery(hql, Utilizador.class)
                .setParameter("username", username)
                .setParameter("password", password)
                .uniqueResult();
        session.close();
        return user != null;
    }
    
    /**
     * Obtém o utilizador por username.
     * @param username - o username do utilizador.
     */
    public Utilizador utilizadorPorUsername(String username) {
        Session session = sessionFactory.openSession();
        String hql = "FROM User WHERE username = :username";
        Utilizador user = session.createQuery(hql, Utilizador.class)
                .setParameter("username", username)
                .uniqueResult();
        session.close();
        return user;
    }
}
