package agenda;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;
@Entity
public class Utilizador {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String username;
	private String password;
	
	//Relação OneToMany com Tarefa
	@OneToMany(mappedBy = "utilizador", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Tarefa> tarefas = new ArrayList<>();
	
	public Utilizador() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Tarefa> getTarefas() {
		return tarefas;
	}
	
	public void addTarefa(Tarefa tarefa) {
		this.tarefas.add(tarefa);
		tarefa.setUtilizador(this);
	}

	@Override
	public String toString() {
		String st = "Utilizador id=" + id + ", username=" + username + ", password=" + password + "\n";
		for (Tarefa t : tarefas) {
			st += " " + t + "\n";
		}
		return st;
	}
	
	
	
}
