package com.upt.lp.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.upt.lp.restapi.model.Tarefa;
import com.upt.lp.restapi.model.Tarefa.Prioridade;
import java.util.List;

@Repository
public interface TarefaRepository extends JpaRepository<Tarefa, Long> {
    //Consultas customizadas para o service
    List<Tarefa> findByPrioridade(Prioridade prioridade);
    
    List<Tarefa> findAllByOrderByDataFDesc();
}