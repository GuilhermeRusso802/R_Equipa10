package com.upt.lp.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.upt.lp.restapi.model.Tarefa;
import com.upt.lp.restapi.model.Tarefa.Prioridade;
import com.upt.lp.restapi.model.Tarefa.Estado;
import java.util.List;

/**
 * TarefaRepository.java
 * Esta classe possui métodos CRUD associados às tarefas que não são suportados nativamente pelo Spring
 * @author Guilherme Russo
 */


@Repository
public interface TarefaRepository extends JpaRepository<Tarefa, Long> {
	List<Tarefa> findByUtilizadorId(Long utilizadorId);
    List<Tarefa> findByUtilizadorIdAndPrioridade(Long utilizadorId, Tarefa.Prioridade prioridade);
    List<Tarefa> findByUtilizadorIdAndEstado(Long utilizadorId, Tarefa.Estado estado);
}