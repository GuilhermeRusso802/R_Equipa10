package com.upt.lp.restapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upt.lp.restapi.model.Utilizador;
import com.upt.lp.restapi.repository.UtilizadorRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UtilizadorService {
    @Autowired
    private UtilizadorRepository utilizadorRepository;
    
    public List<Utilizador> getAllUsers() {
        return utilizadorRepository.findAll();
    }

    public Optional<Utilizador> getUserById(Long id) {
        return utilizadorRepository.findById(id);
    }

    public Utilizador createUser(Utilizador utilizador) {
        return utilizadorRepository.save(utilizador);
    }

    public Utilizador updateUser(Long id, Utilizador utilizadorDetalhes) {
        return utilizadorRepository.findById(id).map(utilizador -> {
            utilizador.setUsername(utilizadorDetalhes.getUsername());
            utilizador.setPassword(utilizadorDetalhes.getPassword());
            return utilizadorRepository.save(utilizador);
        }).orElseThrow(() -> new RuntimeException("Utilizador não encontrado."));
    }

    public void deleteUser(Long id) {
        if (utilizadorRepository.existsById(id)) {
            utilizadorRepository.deleteById(id);
        } else {
            throw new RuntimeException("Utilizador não encontrado.");
        }
    }
}

