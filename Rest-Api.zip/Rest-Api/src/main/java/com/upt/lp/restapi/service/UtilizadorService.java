package com.upt.lp.restapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.upt.lp.restapi.model.Utilizador;
import com.upt.lp.restapi.repository.UtilizadorRepository;

import java.util.List;
import java.util.Optional;

/**
 * UtilizadorService.java
 * Esta classe possui as operações CRUD relacionadas aos utilizadores
 * @author Guilherme Russo
 */
@Service
public class UtilizadorService {
    @Autowired
    private UtilizadorRepository utilizadorRepository;
    
    /**
     * Obtém todos os utilizadores
     */
    public List<Utilizador> getAllUtilizadores() {
        return utilizadorRepository.findAll();
    }

    /**
     * Obtém um utilizador pelo seu id
     * @param id - o id do utilizador
     */
    public Optional<Utilizador> getUtilizadorById(Long id) {
        return utilizadorRepository.findById(id);
    }
    
    /**
     * Obtém um utilizador pelo seu username
     * @param username - o username do utilizador
     */
    public Optional<Utilizador> getUtilizadorByUsername(String username) {
        return utilizadorRepository.findByUsername(username);
    }

    /**
     * Cria um novo utilizador
     * @param utilizador - o novo utilizador
     */
    public Utilizador createUtilizador(Utilizador utilizador) {
        return utilizadorRepository.save(utilizador);
    }
    
    /**
     * Atualiza a informação de um utilizador
     * @param id - o id do utilizador
     * @param utilizadorDetalhes - a nova informação do utilizador
     */
    public Utilizador updateUtilizador(Long id, Utilizador utilizadorDetalhes) {
        return utilizadorRepository.findById(id).map(utilizador -> {
            utilizador.setUsername(utilizadorDetalhes.getUsername());
            utilizador.setPassword(utilizadorDetalhes.getPassword());
            return utilizadorRepository.save(utilizador);
        }).orElseThrow(() -> new RuntimeException("Utilizador não encontrado com ID: " + id));
    }

    /**
     * Apaga um utilizador da base de dados
     * @param id - o id do utilizador a apagar
     */
    public void deleteUtilizador(Long id) {
        if (utilizadorRepository.existsById(id)) {
            utilizadorRepository.deleteById(id);
        } else {
            throw new RuntimeException("Utilizador não encontrado.");
        }
    }
    
    /**
     * Valida o login do utilizador
     * @param username - o username do utilizador
     * @param password - a password do utilizador
     */
    public boolean validateLogin(String username, String password) {
        Optional<Utilizador> utilizador = utilizadorRepository.findByUsername(username);
        return utilizador.isPresent() && utilizador.get().getPassword().equals(password);
    }
}

