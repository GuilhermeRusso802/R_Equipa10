package com.upt.lp.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.upt.lp.restapi.model.*;
import com.upt.lp.restapi.service.*;
import com.upt.lp.restapi.model.Tarefa.Prioridade;

import java.util.List;

/** 
* TarefaController.java 
* Esta classe lida com requisições HTTP para as operações CRUD relacionadas às Tarefas. 
* @author Guilherme Russo 
*/ 

@RestController
@RequestMapping("/api/tarefas")
public class TarefaController {

    @Autowired
    private TarefaService tarefaService;
    
    /**
     * Obtém as Tarefas associadas a um utilizador
     * @param utilizadorId - id do utilizador associado.
     */
    @GetMapping
    public ResponseEntity<List<Tarefa>> getAllTarefas(@RequestParam Long utilizadorId) {
        List<Tarefa> tarefas = tarefaService.getTarefasByUtilizadorId(utilizadorId);
        return ResponseEntity.ok(tarefas);
    }
    
    /**
     * Obtém uma tarefa pelo seu id
     * @param id - id da tarefa
     */
    @GetMapping("/{id}")
    public ResponseEntity<Tarefa> getTarefaById(@PathVariable Long id) {
        return tarefaService.getTarefaById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    /**
     * Obtém as tarefas pelo id do utilizador
     * @param utilizadorId - id do utilizador
     */
    @GetMapping("/utilizadores/{utilizadorId}")
    public ResponseEntity<List<Tarefa>> getTarefasByUserId(@PathVariable Long utilizadorId) {
        List<Tarefa> tarefas = tarefaService.getTarefasByUtilizadorId(utilizadorId);
        return ResponseEntity.ok(tarefas);
    }
    
    /**
     * Obtém as tarefas de uma prioridade específica
     * @param prioridade - a prioridade a pesquisar
     * @param utilizadorId - o id do utilizador associado
     */
    @GetMapping("/prioridade/{prioridade}")
    public ResponseEntity<List<Tarefa>> getTarefasByPrioridade(
            @PathVariable Tarefa.Prioridade prioridade, 
            @RequestParam Long utilizadorId) {
        List<Tarefa> tarefas = tarefaService.getTarefasByUtilizadorAndPrioridade(utilizadorId, prioridade);
        return ResponseEntity.ok(tarefas);
    }
    
    /**
     * Obtém as tarefas de um estado específico
     * @param estado - o estado a pesquisar
     * @param utilizadorId - o id do utilizador associado
     */
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Tarefa>> getTarefasByEstado(
            @PathVariable Tarefa.Estado estado, 
            @RequestParam Long utilizadorId) {
        List<Tarefa> tarefas = tarefaService.getTarefasByUtilizadorAndEstado(utilizadorId, estado);
        return ResponseEntity.ok(tarefas);
    }

    /**
     * Cria uma tarefa
     * @param utilizadorId - o id do utilizador a associar
     * @param tarefa - a nova tarefa
     * @return 
     */
    @PostMapping("/utilizadores/{utilizadorId}")
    public Tarefa createTarefa(@PathVariable Long utilizadorId, @RequestBody Tarefa tarefa) {
        return tarefaService.createTarefa(utilizadorId, tarefa);
    }

    /**
     * Atualiza a informação de uma tarefa
     * @param id - o id da tarefa
     * @param tarefaDetails - as novas informações da tarefa
     */
    @PutMapping("/{id}")
    public ResponseEntity<Tarefa> updateTarefa(@PathVariable Long id, @RequestBody Tarefa tarefaDetails) {
        try {
            return ResponseEntity.ok(tarefaService.updateTarefa(id, tarefaDetails));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Apaga uma tarefa
     * @param id - id da tarefa a apagar
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTarefa(@PathVariable Long id) {
        try {
            tarefaService.deleteTarefa(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}