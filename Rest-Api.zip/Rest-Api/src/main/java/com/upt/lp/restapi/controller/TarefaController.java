package com.upt.lp.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.upt.lp.restapi.model.*;
import com.upt.lp.restapi.service.*;
import com.upt.lp.restapi.model.Tarefa.Prioridade;

import java.util.List;

@RestController
@RequestMapping("/api/tarefas")
public class TarefaController {

    @Autowired
    private TarefaService tarefaService;

    @GetMapping
    public List<Tarefa> getAllTarefas() {
        return tarefaService.getAllTarefas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tarefa> getTarefaById(@PathVariable Long id) {
        return tarefaService.getTarefaById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/prioridade/{prioridade}")
    public List<Tarefa> getTarefasByPrioridade(@PathVariable Prioridade prioridade) {
        return tarefaService.getTarefasByPrioridade(prioridade);
    }
    
    @GetMapping("/ordenadas")
    public List<Tarefa> listarTarefasOrdenadasDesc() {
        return tarefaService.getTarefasByDataF();
    }

    @PostMapping
    public Tarefa createTarefa(@RequestBody Tarefa tarefa) {
        return tarefaService.createTarefa(tarefa);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tarefa> updateTarefa(@PathVariable Long id, @RequestBody Tarefa tarefaDetails) {
        try {
            return ResponseEntity.ok(tarefaService.updateTarefa(id, tarefaDetails));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTarefa(@PathVariable Long id) {
        try {
            tarefaService.deleteTarefa(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}