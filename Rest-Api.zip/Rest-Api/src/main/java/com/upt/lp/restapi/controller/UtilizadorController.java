package com.upt.lp.restapi.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import  com.upt.lp.restapi.model.Utilizador;
import  com.upt.lp.restapi.service.UtilizadorService;

import java.util.List;


@RestController
@RequestMapping("/api/utilizadores")
public class UtilizadorController {

    @Autowired
    private UtilizadorService utilizadorService;

    @GetMapping
    public List<Utilizador> getAllUsers() {
        return utilizadorService.getAllUsers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Utilizador> getUtilizadorById(@PathVariable Long id) {
        return utilizadorService.getUserById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Utilizador createUser(@RequestBody Utilizador utilizador) {
        return utilizadorService.createUser(utilizador);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Utilizador> updateUser(@PathVariable Long id, @RequestBody Utilizador utilizadorDetalhes) {
        try {
            return ResponseEntity.ok(utilizadorService.updateUser(id, utilizadorDetalhes));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        try {
            utilizadorService.deleteUser(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
