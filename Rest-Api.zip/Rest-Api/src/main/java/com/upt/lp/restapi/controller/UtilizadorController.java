package com.upt.lp.restapi.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import  com.upt.lp.restapi.model.Utilizador;
import  com.upt.lp.restapi.service.UtilizadorService;

import java.util.List;
import java.util.Optional;

/** 
* UtilizadorController.java 
* Esta classe lida com requisições HTTP para as operações CRUD relacionadas aos utilizadores. 
* @author Guilherme Russo 
*/ 


@RestController
@RequestMapping("/api/utilizadores")
public class UtilizadorController {

    @Autowired
    private UtilizadorService utilizadorService;
    
    /**
 	*Obtém todos os utilizadores 
 	*/
    @GetMapping
    public List<Utilizador> getAllUtilizadores() {
        return utilizadorService.getAllUtilizadores();
    }

    /**
     * Obtém um utilizador pelo seu id
     * @param id - id do utilizador
     */
    @GetMapping("/{id}")
    public ResponseEntity<Utilizador> getUtilizadorById(@PathVariable Long id) {
        return utilizadorService.getUtilizadorById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    /**
     * Obtém um utilizador pelo seu username
     * @param username - o username do utilizador
     */
    @GetMapping("/username/{username}")
    public ResponseEntity<Optional<Utilizador>> getUtilizadorByUsername(@PathVariable String username) {
        Optional<Utilizador> utilizador = utilizadorService.getUtilizadorByUsername(username);
        return utilizador != null ? ResponseEntity.ok(utilizador) : ResponseEntity.notFound().build();
    }
    
    /**
     * Cria um novo utilizador
     * @param utilizador - o novo utilizador
     */
    @PostMapping
    public Utilizador createUtilizador(@RequestBody Utilizador utilizador) {
        return utilizadorService.createUtilizador(utilizador);
    }

    /**
     * Atualiza as informações de um utilizador
     * @param id - o id do utilizador
     * @param utilizadorDetalhes - os detalhes do utilizador
     * @return
     */
    @PutMapping("/{id}")
    public ResponseEntity<Utilizador> updateUtilizador(@PathVariable Long id, @RequestBody Utilizador utilizadorDetalhes) {
        try {
            return ResponseEntity.ok(utilizadorService.updateUtilizador(id, utilizadorDetalhes));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Apaga as informações de um utilizador
     * @param id - o id do utilizador
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUtilizador(@PathVariable Long id) {
        try {
            utilizadorService.deleteUtilizador(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * Autentica as credenciais do utilizador
     * @param loginDetails - os detalhes de login do utilizador
     */
    @PostMapping("/login")
    public ResponseEntity<Boolean> loginUtilizador(@RequestBody Utilizador loginDetails) {
        boolean isAuthenticated = utilizadorService.validateLogin(loginDetails.getPassword(), loginDetails.getPassword());
        if (isAuthenticated) {
            return ResponseEntity.ok(true);
        } else {
            return ResponseEntity.status(401).body(false);
        }
    }
}
