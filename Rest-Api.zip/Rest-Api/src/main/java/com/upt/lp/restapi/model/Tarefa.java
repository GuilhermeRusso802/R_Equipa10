package com.upt.lp.restapi.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.upt.lp.restapi.model.Tarefa.Prioridade;
import com.upt.lp.restapi.model.Tarefa.Estado;

/** 
* Tarefa.java 
* Esta classe conecta a uma tabela na base de dados. 
* @author Guilherme Russo 
*/ 

@Entity
@Table(name = "tarefas")
public class Tarefa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String titulo;

    private String descricao;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @Enumerated(EnumType.STRING)
    private Prioridade prioridade;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    
    @ManyToOne
    @JoinColumn(name = "utilizador_id", referencedColumnName = "id")
    @JsonBackReference
    private Utilizador utilizador;
    
    //Define estado como POR_FAZER por default
    public Tarefa() {
        this.estado = Estado.POR_FAZER;  
        }



    /**
     * @return o id da tarefa
     */
    public long getId() {
        return id;
    }
    
    /**
     * @param id - o id da tarefa
     */
    public void setId(long id) {
        this.id = id;
    }
    
    /**
     * @return o titulo da tarefa
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo - o título da tarefa
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return a descricao da tarefa
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao - a descricao da tarefa
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return a data de fim da tarefa
     */
    public LocalDate getDataFim() {
        return dataFim;
    }

    /**
     * @param dataFim - a data de fim da tarefa
     */
    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    /**
     * @return a prioridade da tarefa
     */
    public Prioridade getPrioridade() {
        return prioridade;
    }

    /**
     * @param prioridade - a prioridade da tarefa
     */
    public void setPrioridade(Prioridade prioridade) {
        this.prioridade = prioridade;
    }

    /**
     * @return o estado da tarefa
     */
    public Estado getEstado() {
        return estado;
    }
   
    /**
     * @param estado - o estado da tarefa
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    /**
     * @return o utilizador associado à tarefa
     */
    public Utilizador getUtilizador() {
        return utilizador;
    }

    /**
     * @param utilizador - o utilizador associado à tarefa
     */
    public void setUtilizador(Utilizador utilizador) {
        this.utilizador = utilizador;
    }
    
    //Valores possíveis para a prioridade
    public enum Prioridade {
        BAIXA, MEDIA, ALTA;
    }

    //Valores possíveis para o estado
    public enum Estado {
        POR_FAZER, EM_PROGRESSO, CONCLUIDA;
    }

	@Override
	public String toString() {
		return "Tarefa [id=" + id + ", titulo=" + titulo + ", descricao=" + descricao + ", dataFim=" + dataFim + ", prioridade=" + prioridade + ", estado=" + estado + ", utilizador=" + utilizador + "]";
	}
}


