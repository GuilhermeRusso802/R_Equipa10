package com.upt.lp.restapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upt.lp.restapi.model.Tarefa;
import com.upt.lp.restapi.model.Tarefa.Prioridade;
import com.upt.lp.restapi.model.Tarefa.Estado;
import com.upt.lp.restapi.repository.TarefaRepository;

import java.util.List;
import java.util.Optional;

@Service
public class TarefaService {
    @Autowired
    private TarefaRepository tarefaRepository;

    public List<Tarefa> getAllTarefas() {
        return tarefaRepository.findAll();
    }

    public Optional<Tarefa> getTarefaById(Long id) {
        return tarefaRepository.findById(id);
    }
    
    /**
     * Cria uma tarefa
     * @param tarefa - a tarefa a ser criada
     */
    public Tarefa createTarefa(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }
    
    /**
	* @param id - o identificador da tarefa
	* @param tarefaDetalhes - os detalhes da Tarefa
     */
    public Tarefa updateTarefa(Long id, Tarefa tarefaDetalhes) {
        return tarefaRepository.findById(id).map(tarefa -> {
            tarefa.setTitulo(tarefaDetalhes.getTitulo());
            tarefa.setDescricao(tarefaDetalhes.getDescricao());
            tarefa.setDataF(tarefaDetalhes.getDataF());
            tarefa.setPrioridade(tarefaDetalhes.getPrioridade());
            tarefa.setEstado(tarefaDetalhes.getEstado());
            return tarefaRepository.save(tarefa);
        }).orElseThrow(() -> new RuntimeException("Tarefa não encontrada com ID: " + id));
    }
    
    /**
	* Apaga a tarefa com o identificador referido
	* @param id - o identificador da tarefa
     */
    public void deleteTarefa(Long id) {
        if (tarefaRepository.existsById(id)) {
            tarefaRepository.deleteById(id);
        } else {
            throw new RuntimeException("Tarefa não encontrada com ID: " + id);
        }
    }	
    
    /**
     * Retorna todas as tarefas de uma certa prioridade.
     * @param a prioridade a ser pesquisada
     * @return Tarefas da prioridade referida.
     */
    public List<Tarefa> getTarefasByPrioridade(Prioridade prioridade) {
        return tarefaRepository.findByPrioridade(prioridade);
    }
    
    /**
     * Retorna todas as tarefas ordenadas por data de fim (decrescente).
     * @return Lista de tarefas ordenadas por dataF em ordem decrescente.
     */
    public List<Tarefa> getTarefasByDataF() {
        return tarefaRepository.findAllByOrderByDataFDesc();
    }
}
