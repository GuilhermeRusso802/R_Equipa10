package com.upt.lp.restapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upt.lp.restapi.model.Tarefa;
import com.upt.lp.restapi.model.Tarefa.Prioridade;
import com.upt.lp.restapi.model.Tarefa.Estado;
import com.upt.lp.restapi.repository.TarefaRepository;
import com.upt.lp.restapi.repository.UtilizadorRepository;

import java.util.List;
import java.util.Optional;

/**
 * TarefaService.java
 * Esta classe define os métodos CRUD relacionados às tarefas
 * @author Guilherme Russo
 */

@Service
public class TarefaService {
    @Autowired
    private TarefaRepository tarefaRepository;
    
    @Autowired
    private UtilizadorRepository utilizadorRepository;

    /**
     * Obtém todas as tarefas
     * @return as tarefas
     */
    public List<Tarefa> getAllTarefas() {
        return tarefaRepository.findAll();
    }

    /**
     * Obtém uma tarefa pelo seu id
     * @param id - o id da tarefa
     * @return a tarefa
     */
    public Optional<Tarefa> getTarefaById(Long id) {
        return tarefaRepository.findById(id);
    }
    
    /**
     * Obtém as tarefas pelo id de um utilizador
     * @param utilizadorId - o id do utilizador
     * @return as tarefas do utilizador
     */
    public List<Tarefa> getTarefasByUtilizadorId(Long utilizadorId) {
        return tarefaRepository.findByUtilizadorId(utilizadorId);
    }

    /**
     * Cria uma tarefa
     * @param utilizadorId - o id do utilizador associado
     * @param tarefa - a tarefa a ser criada
     * @return cria a tarefa
     */
    public Tarefa createTarefa(Long utilizadorId, Tarefa tarefa) {
    	return utilizadorRepository.findById(utilizadorId).map(utilizador -> {
            tarefa.setUtilizador(utilizador);
            return tarefaRepository.save(tarefa);
        }).orElseThrow(() -> new RuntimeException("Utilizador não encontrado com ID: " + utilizadorId));
    }
    
    /**
     * Atualiza uma tarefa
	* @param id - o identificador da tarefa
	* @param tarefaDetalhes - os detalhes da Tarefa
	* @return Atualiza a tarefa
     */
    public Tarefa updateTarefa(Long id, Tarefa tarefaDetalhes) {
        return tarefaRepository.findById(id).map(tarefa -> {
            tarefa.setTitulo(tarefaDetalhes.getTitulo());
            tarefa.setDescricao(tarefaDetalhes.getDescricao());
            tarefa.setDataFim(tarefaDetalhes.getDataFim());
            tarefa.setPrioridade(tarefaDetalhes.getPrioridade());
            tarefa.setEstado(tarefaDetalhes.getEstado());
            return tarefaRepository.save(tarefa);
        }).orElseThrow(() -> new RuntimeException("Tarefa não encontrada com ID: " + id));
    }
    
    /**
	* Apaga a tarefa com o identificador referido
	* @param id - o identificador da tarefa
     */
    public void deleteTarefa(Long id) {
        if (tarefaRepository.existsById(id)) {
            tarefaRepository.deleteById(id);
        } else {
            throw new RuntimeException("Tarefa não encontrada com ID: " + id);
        }
    }	
    
    /**
     * Retorna todas as tarefas de uma certa prioridade.
     * @param utilizadorId - o identificador do utilizador
     * @param prioridade-  a prioridade a ser pesquisada
     * @return Tarefas da prioridade referida.
     */
    public List<Tarefa> getTarefasByUtilizadorAndPrioridade(Long utilizadorId, Tarefa.Prioridade prioridade) {
        return tarefaRepository.findByUtilizadorIdAndPrioridade(utilizadorId, prioridade);
    }
    
    /**
     * Retorna todas as tarefas de um certo estado.
     * @param utilizadorId - o identificador do utilizador
     * @param estado -  o estado a ser pesquisado
     * @return Tarefas do estado referida.
     */
    public List<Tarefa> getTarefasByUtilizadorAndEstado(Long utilizadorId, Tarefa.Estado estado) {
        return tarefaRepository.findByUtilizadorIdAndEstado(utilizadorId, estado);
    }
    
}
